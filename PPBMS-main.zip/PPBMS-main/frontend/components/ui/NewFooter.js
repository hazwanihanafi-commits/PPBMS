export default function NewFooter() {
  return (
    <footer className="text-center py-6 text-gray-500 text-sm mt-10">
      © 2025 PPBMS · Universiti Sains Malaysia · Built with ♥
    </footer>
  );
}
